﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ConsoleApp6
{
    public class Goal
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        private int id;
        public int Id { get; set; }

        [ForeignKey("User")]
        public int UserId { get; set; }

        [ForeignKey("Category")]
        public int categoryId { get; set; }
        public string Name { get; set; }

        [StringLength(100, ErrorMessage = "Description cannot exceed 500 characters.")]
        public string Description { get; set; }

        public DateTime StartDate { get; set; }
      
        public DateTime EndDate { get; set; }

        public bool IsCompleted { get; set; }

        public User User { get; set; }

        public Category Category { get; set; }

        // Create a new goal and add it to the database
        public static void CreateGoal(User user, Goal newGoal, GoalDbContext context)
        {
            newGoal.UserId = user.Id;
            context.Goals.Add(newGoal);
            context.SaveChanges();
            Console.WriteLine("New goal added successfully!");
        }

        // Retrieve all goals for a specific user from the database
        public static void ViewGoals(User user, GoalDbContext context, int cId)
        {
            var userGoals = context.Goals.Where(g => g.UserId == user.Id && g.categoryId==cId).ToList();

            Console.WriteLine("\nYour Goals:");
            foreach (var goal in userGoals)
            {
                Console.WriteLine($"Goal ID: {goal.Id}, Name: {goal.Name}, Description: {goal.Description}, Start Date: {goal.StartDate}, End Date: {goal.EndDate}, Is Completed: {goal.IsCompleted}");
            }
        }

        // Update the details of an existing goal in the database
        public static void UpdateGoal(User user, int goalId, Goal updatedGoal, GoalDbContext context, int cId)
        {
            Goal goalToUpdate = context.Goals.FirstOrDefault(g => g.Id == goalId && g.UserId == user.Id  && g.categoryId==cId);

            if (goalToUpdate != null)
            {
              //  goalToUpdate.Name = updatedGoal.Name;
                goalToUpdate.Description = updatedGoal.Description;
              //  goalToUpdate.StartDate = updatedGoal.StartDate;
                goalToUpdate.EndDate = updatedGoal.EndDate;
                goalToUpdate.IsCompleted = updatedGoal.IsCompleted;

                context.SaveChanges();
                Console.WriteLine("Goal updated successfully!");
            }
            else
            {
                Console.WriteLine("Invalid goal ID or you don't have permission to update this goal.");
            }
        }

        // Delete a goal from the database
        public static void DeleteGoal(User user, int goalId, GoalDbContext context)
        {
            Goal goalToDelete = context.Goals.FirstOrDefault(g => g.Id == goalId && g.UserId == user.Id);

            if (goalToDelete != null)
            {
                context.Goals.Remove(goalToDelete);
                context.SaveChanges();
                Console.WriteLine("Goal deleted successfully!");
            }
            else
            {
                Console.WriteLine("Invalid goal ID or you don't have permission to delete this goal.");
            }
        }
        private static string GetUserInput(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }
        public static Goal CreateNewGoalFromUserInput(int catId)
        {
            Console.WriteLine("\nEnter details for the new goal:");

            string name = GetUserInput("Name: ");
            while (string.IsNullOrWhiteSpace(name))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Name cannot be empty. Please enter a valid name.");
                Console.ResetColor();
                name = GetUserInput("Name: ");
            }

            string description = GetUserInput("Description: ");
            while (string.IsNullOrWhiteSpace(description))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Description cannot be empty. Please enter a valid description.");
                Console.ResetColor();
                description = GetUserInput("Description: ");
            }

            DateTime startDate;
            while (!DateTime.TryParseExact(GetUserInput("Start Date (YYYY-MM-DD): "), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out startDate))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid date format. Please enter a valid date in the format YYYY-MM-DD.");
                Console.ResetColor();
            }

            DateTime endDate;
            while (!DateTime.TryParseExact(GetUserInput("End Date (YYYY-MM-DD): "), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out endDate))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid date format. Please enter a valid date in the format YYYY-MM-DD.");
                Console.ResetColor();
            }

            if (endDate < startDate)
            {
                Console.WriteLine("End date cannot be earlier than the start date. Please enter valid dates.");
                return null; // Or handle the situation in your preferred way.
            }

            return new Goal
            {
                Name = name,
                Description = description,
                StartDate = startDate,
                EndDate = endDate,
                IsCompleted = false,
                categoryId = catId
            };
        }

        public static int GetGoalIdFromUserInput()
        {
            int goalId;

            while (true)
            {
                string input = GetUserInput("Enter the ID of the goal: ");
                if (int.TryParse(input, out goalId))
                {
                    return goalId;
                }
                Console.WriteLine("Invalid input. Please enter a valid integer.");
            }
        }

        public static Goal CreateUpdatedGoalFromUserInput()
        {
            Console.WriteLine("\nEnter updated details for the goal:");
          //  string name = GetUserInput("Updated Name: ");
            string description = GetUserInput("Updated Description: ");
          //  DateTime startDate = DateTime.Parse(GetUserInput("Updated Start Date (YYYY-MM-DD): "));

            DateTime endDate = DateTime.Parse(GetUserInput("Updated End Date (YYYY-MM-DD): "));
            bool isCompleted = bool.Parse(GetUserInput("Is Completed (True/False): "));

            return new Goal
            {
              //  Name = name,
                Description = description,
               // StartDate = startDate,
                EndDate = endDate,
                IsCompleted = isCompleted
            };
        }


    }
}
