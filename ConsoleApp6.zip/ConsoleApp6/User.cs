﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public  class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }


        public string Username { get; set; }

       
        public string Password { get; set; }

        private string role;
        public string Role
        {
            get { return role; }
            set
            {
                if (value != null)
                    role = value;
                else
                    role = "user";
            }
        }

        public User()
        {
            role = "user";
        }

        public  static void userList(User admin, GoalDbContext context)
        {
            var userList = context.Users.Select(u=>u).ToList();

            Console.WriteLine("\nYour Goals:");
            foreach (var user in userList)
            {
                Console.WriteLine("User Id:"+user.Id+"  "+"Username:"+user.Username);
            }
        }

        internal static void deleteUser(User admin, GoalDbContext context)
        {
            Console.WriteLine("Enter user Id:");
            int id = Convert.ToInt32( Console.ReadLine());
            User userToDelete = context.Users.FirstOrDefault(g => g.Id == id );

            if (userToDelete != null)
            {
                context.Users.Remove(userToDelete);
                context.SaveChanges();
                Console.WriteLine("User deleted successfully!");
            }
            else
            {
                Console.WriteLine("Invalid user ID or you don't have permission to delete this goal.");
            }
        }
    }
}
