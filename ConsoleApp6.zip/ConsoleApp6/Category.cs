﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp6
{
    public  class Category
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {
            return "Id:" + this.Id + "  Name:" + this.Name + " Description:" + this.Description;
        }

        public static int categoryList( GoalDbContext context)
        {
            var categoryList = context.Categories.Select(u => u).ToList();

            Console.WriteLine("\nCategories");
            foreach (var category in categoryList)
            {
                Console.WriteLine(category.Id+". "+category.Name);
            }
            Console.WriteLine("Enter choice:");
            int choice = Convert.ToInt32( Console.ReadLine());
            return choice;
        }

        public static void adminCategoryList(GoalDbContext context)
        {
            var categoryList = context.Categories.Select(u => u).ToList();

            Console.WriteLine("\nCategories");
            foreach (var category in categoryList)
            {
                Console.WriteLine(category);
            }
        }

        internal static void updateCategory(int id, string description, GoalDbContext context)
        {
           Category c = context.Categories.FirstOrDefault(g => g.Id == id );

            if (c != null)
            {
                c.Description = description;

                context.SaveChanges();
                Console.WriteLine("Category updated successfully!");
            }
            else
            {
                Console.WriteLine("Invalid category ID .");
            }
        }

        internal static void deleteCategory(GoalDbContext context)
        {
            Console.WriteLine("Enter Id:");
            int id = Convert.ToInt32(Console.ReadLine());
            Category c = context.Categories.FirstOrDefault(g => g.Id == id);
            if (c != null)
            {
                context.Categories.Remove(c);
                context.SaveChanges();
                Console.WriteLine("Category deleted successfully!");
            }
            else
            {
                Console.WriteLine("Invalid category ID ");
            }
        }

        internal static void addCategory(Category c,GoalDbContext context)
        {
            
            context.Categories.Add(c);
            context.SaveChanges();
            Console.WriteLine("New category added successfully!");
        }


        public static Category CreateNewGoalFromUserInput()
        {
            Console.WriteLine("\nEnter  new category:");
            Console.WriteLine("Enter name:");

            string name = Console.ReadLine();
            Console.WriteLine("Enter description:");
            string description = Console.ReadLine();

            return new Category
            {
                Name = name,
                Description = description,
                
            };
        }

      

        public static void CreateUpdatedCategory(GoalDbContext context)
        {
            Console.WriteLine("\nUpdate Category:");
            Console.WriteLine("Enter id:");
            int id = Convert.ToInt32( Console.ReadLine());
            var c=context.Categories.Select(c => c.Id == id);
            if (c != null)
            {

                Console.WriteLine("Enter description:");
                string description = Console.ReadLine();

                updateCategory(id, description,context);

            }
           
        }
    }
}
