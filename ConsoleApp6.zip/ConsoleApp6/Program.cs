﻿using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace ConsoleApp6
{
    internal class Program
    {
        private static List<User> users = new List<User>();
        private static List<Goal> goals = new List<Goal>();
        private static int currentUserId = 1;

        static void RegisterUser(GoalDbContext context)
        {
            Console.WriteLine("\nUser Registration");

            string username;
            do
            {
                Console.Write("Enter username: ");
                username = Console.ReadLine();
                if (username.Length < 3)
                {
                    Console.ForegroundColor = ConsoleColor.Red;

            
                    Console.WriteLine("Enter a valid username (at least 3 characters).");
                    Console.ResetColor();
                }
                else if (context.Users.Any(u => u.Username == username))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Username already exists. Please try again with a different username.");
                    Console.ResetColor();
                }
            } while (username.Length < 3 || context.Users.Any(u => u.Username == username));

            string password;
            string complexityPattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$";
            do
            {
                Console.Write("Enter password: ");
                password = Console.ReadLine();
                if (!Regex.IsMatch(password, complexityPattern))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid password. The password must be at least 8 characters long and include at least one lowercase letter, one uppercase letter, one digit, and one special character.");
                    Console.ResetColor();
                }
            } while (!Regex.IsMatch(password, complexityPattern));

            User newUser = new User
            {
                Username = username,
                Password = password
            };

            context.Users.Add(newUser);
            context.SaveChanges();
            Console.WriteLine("Registration successful! You can now log in.");
        }

        static void LoginUser(GoalDbContext context)
        {
            Console.WriteLine("\nUser Login");

            Console.Write("Enter username: ");
            string username = Console.ReadLine();

            Console.Write("Enter password: ");
            string password = Console.ReadLine();

            User admin = context.Users.FirstOrDefault(u => username == "admin" && password == "admin123");
            if (admin != null)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Admin Login successful!");
                Console.ResetColor();
                ShowAdminOptions(admin, context);

            }
            User user = context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);


            if (user != null)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Login successful!");
                Console.ResetColor();
                int categoryID=Category.categoryList(context);
                ShowGoalOptions(user, context,categoryID);
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid username or password. Please try again.");
                Console.ResetColor();
            }
        }

        private static void ShowAdminOptions(User admin, GoalDbContext context)
        {
            while (true)
            {
                Console.WriteLine("\nGoal Options");
                Console.WriteLine("1. List Users\n2. Delete User \n3. List Categories \n4. Update Categories \n5. Delete Categories \n6. Add new Category \n7.Logout");
                Console.Write("Enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.WriteLine("\nUser List");
                        User.userList(admin, context);
                        break;
                    case "2":
                        User.deleteUser(admin, context);
                        break;
                    case "3":
                        Category.adminCategoryList(context);
                        break;
                    case "4":
                        Category.CreateUpdatedCategory(context);
                        break;
                    case "5":
                        Category.deleteCategory(context);
                        break;
                    case "6":
                        Category c=Category.CreateNewGoalFromUserInput();
                        Category.addCategory(c, context);
                        break;
                    case "7":
                        Console.WriteLine("logged out successfully");
                        Program.Main();
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
        static void ShowGoalOptions(User user, GoalDbContext context, int categoryId)
        {
            while (true)
            {
                Console.WriteLine("\nGoal Options");
                Console.WriteLine("1. Add New Goal\n2. View Goals\n3. Update Goal\n4. Delete Goal\n5. Logout");
                Console.Write("Enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.WriteLine("\nAdd New Goal");
                        Goal newGoal = Goal.CreateNewGoalFromUserInput(categoryId);
                        Goal.CreateGoal(user, newGoal, context);
                        break;
                    case "2":
                        Goal.ViewGoals(user, context, categoryId);
                        break;
                    case "3":
                        Console.WriteLine("\nUpdate Goal");
                        int goalIdToUpdate = Goal.GetGoalIdFromUserInput();
                        Goal updatedGoal = Goal.CreateUpdatedGoalFromUserInput();
                        Goal.UpdateGoal(user, goalIdToUpdate, updatedGoal, context,categoryId);
                        break;
                    case "4":
                        Console.WriteLine("\nDelete Goal");
                         int goalIdToDelete = Goal.GetGoalIdFromUserInput();
                        Goal.DeleteGoal(user, goalIdToDelete, context);
                        break;
                    case "5":
                        Program.Main();
                        Console.WriteLine("Logging out...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }


        static void Main()
        {

            Console.WriteLine("Welcome to Goal Tracking Application!");

            var context = new GoalDbContext();
            
                // Apply migrations and create the database if it doesn't exist
                //User admin=new User { Username="admin", Password="admin123", Role="admin" };
                //Console.WriteLine(admin.Id + " " + admin.Role);
                context.Database.Migrate();
               // context.Users.Add(admin);
                
                context.SaveChanges();
                while (true)
                {
                    Console.WriteLine("\n1. Register\n2. Login\n3. Exit");
                    Console.Write("Enter your choice: ");
                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            RegisterUser(context);
                            break;
                        case "2":
                            LoginUser(context);
                            break;
                        case "3":
                            Console.WriteLine("Goodbye!");
                            return;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
            
        }
    }
}